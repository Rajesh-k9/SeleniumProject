This framework is built using TestNG.
Followed Page Object Model framework to build this framework.
Used GalenTestNgTestBase for checking on multiple browsers.

Framework contains following packages:

- com.test.fox.TestFramework.componentss:
  This package contains following classes
  1. BrowserDetails.java - this constructs the browser details
  2. FoxAutoBaseClass.java - this extends GalenTestNgTestBase, based on the browser, it creates the driver. This class is extended by testClass
  
 - com.test.fox.TestFramework.pages
  This package contains following classes
  1. BasePage.java - Basic initialization
  2. HomePage.java - this contains elements on HomePage page and related methods
  3. ShowsPage.java - this contains elements on ShowsPage page and related methods
  4. SignInPage.java - this contains elements on SignInPage page and related methods
  
 - com.test.fox.TestFramework.utilities
  1. Utilities.java - This contains some generic( common) methods like Creating the excel, updating the excel, properties reading
 
 - com.test.fox.TestFramework.tests
   This package contains following test class
   1. FoxAutoTests.java - this contains testNg tests, which are executable tests.
  
 Framework contains Config.properties file which contains information about testURL, path of chromedriver, path of firefoxdriver, path of iedriver
 username, password, Lastshow names of FOX, FX, National Geographic, FOX Sports and All Shows.

 To run the tests
 1. run by testng.xml -> right click on the testng.xml and select Run As and select TestNG Suite
 2. run by using testClass -> right click on the FoxAutoTests.java and select Run as and select TestNG Test.