package com.test.fox.TestFramework.tests;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.test.fox.TestFramework.components.BrowserDetails;
import com.test.fox.TestFramework.components.FoxAutoBaseClass;
import com.test.fox.TestFramework.pages.HomePage;
import com.test.fox.TestFramework.pages.ShowsPage;
import com.test.fox.TestFramework.pages.SignInPage;
import com.test.fox.TestFramework.utilities.Utitlities;

public class FoxAutoTests extends FoxAutoBaseClass {
	static Properties props;
	static ArrayList<String> last4ShowsList = new ArrayList<String>();
	static ArrayList<String> fxShowsList = new ArrayList<String>();
	static ArrayList<String> ngShowsList = new ArrayList<String>();
	static ArrayList<String> allShowsList = new ArrayList<String>();
	static ArrayList<String> foxsportsList = new ArrayList<String>();
	
	@BeforeClass
	public void setTestData(){
		System.out.println("Before Class");
		props = Utitlities.readConfigfile(System.getProperty("user.dir")+"\\Config.properties");
	}

	@Test(dataProvider = "browsers",priority=1)
	public void test_fxShows(BrowserDetails browser) throws Exception {
		driver = getDriver();
		initizePages(driver);
		load(props.getProperty("url"));	
		System.out.println(driver.getTitle());
		doLogin(driver);
		homePage.openShows();
		checkExcelExistanceStatus();
		homePage.openFXshows();
		showsPage.waitForPagetoLoadAllshows(props.getProperty("FX_lastShow"));
		fxShowsList = showsPage.getAllShows();
		Utitlities.updateWorkBook("FX",last4ShowsList,fxShowsList);

	}

	@Test(dataProvider = "browsers",priority=2)
	public void test_ngShows(BrowserDetails browser) throws Exception {
		driver = getDriver();
		initizePages(driver);
		load(props.getProperty("url"));	
		System.out.println(driver.getTitle());
		doLogin(driver);
		homePage.openShows();			
		checkExcelExistanceStatus();		
		homePage.openNGshows();
		showsPage.waitForPagetoLoadAllshows(props.getProperty("National_Geographic_lastShow"));
		ngShowsList = showsPage.getAllShows();
		Utitlities.updateWorkBook("National Geographic",last4ShowsList,ngShowsList);
	}
	
	@Test(dataProvider = "browsers",priority=3)
	public void test_foxsportsShows(BrowserDetails browser) throws Exception {
		driver = getDriver();
		initizePages(driver);
		load(props.getProperty("url"));	
		System.out.println(driver.getTitle());
		doLogin(driver);
		homePage.openShows();			
		checkExcelExistanceStatus();		
		homePage.openFoxSportsShows();
		showsPage.waitForPagetoLoadAllshows(props.getProperty("FOX_Sports_lastShow"));		
		foxsportsList = showsPage.getAllShows();
		Utitlities.updateWorkBook("FOX Sports",last4ShowsList,foxsportsList);
	}
	
	@Test(dataProvider = "browsers",priority=4)
	public void test_allShows(BrowserDetails browser) throws Exception {
		driver = getDriver();
		initizePages(driver);
		load(props.getProperty("url"));	
		System.out.println(driver.getTitle());
		doLogin(driver);
		homePage.openShows();			
		checkExcelExistanceStatus();				
		homePage.openAllShows();
		showsPage.waitForPagetoLoadAllshows(props.getProperty("AllShows_lastShow"));		
		allShowsList = showsPage.getAllShows();
		Utitlities.updateWorkBook("All Shows",last4ShowsList,allShowsList);
	}

		public void doLogin(WebDriver driver) throws InterruptedException{			
			homePage.launchAccountScreen();
			signInPage.waitForSignInButton();
			signInPage.launchSignInScreen();	
			signInPage.perfomLogin(props.getProperty("username"), props.getProperty("password"));
		}

		public static void initizePages(WebDriver driver){
			homePage=new HomePage(driver);
			signInPage = new SignInPage(driver);
			showsPage = new ShowsPage(driver);
		}
		
		public static void checkExcelExistanceStatus() throws InterruptedException, IOException{
			if(last4ShowsList.size()==0){
				showsPage.waitForPagetoLoadAllshows(props.getProperty("FOX_lastShow"));
				last4ShowsList=showsPage.getLast4Shows();
				Utitlities.createWorkBookwithHeader();
				Utitlities.updateWorkBook("FOX",last4ShowsList,null);
			}
		}

		@AfterMethod
		public void tearDown(){
			driver.quit();
		}
	}
