package com.test.fox.TestFramework.components;

import java.util.List;

import org.openqa.selenium.Dimension;

public class BrowserDetails {

	private final String name;
	private final Dimension screenSize;
	private final String browserType;
	private final List<String> tags;

	public BrowserDetails(String browserType, String name, Dimension screenSize, List<String> tags) {
		this.browserType = browserType;
		this.name = name;
		this.screenSize = screenSize;
		this.tags = tags;
	}

	public String getName() {
		return name;
	}

	public String getBrowserType() {
		return browserType;
	}

	public Dimension getScreenSize() {
		return screenSize;
	}

	public List<String> getTags() {
		return tags;
	}

	@Override
	public String toString() {
		return String.format("%s_%s %dx%d", name, browserType,screenSize.width, screenSize.height);
	}
}
