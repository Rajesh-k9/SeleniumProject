package com.test.fox.TestFramework.components;

import static java.util.Arrays.asList;

import java.util.Properties;

import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.DataProvider;

import com.galenframework.testng.GalenTestNgTestBase;
import com.test.fox.TestFramework.pages.HomePage;
import com.test.fox.TestFramework.pages.ShowsPage;
import com.test.fox.TestFramework.pages.SignInPage;
import com.test.fox.TestFramework.utilities.Utitlities;


public class FoxAutoBaseClass extends GalenTestNgTestBase{

	public WebDriver driver=null;
	protected static HomePage homePage;
	protected static SignInPage signInPage;
	protected static ShowsPage showsPage;
	Properties props = Utitlities.readConfigfile(System.getProperty("user.dir")+"\\Config.properties");
	@DataProvider(name = "browsers")
	public Object [][] devices () {
		return new Object[][] {
				/*
				 * Creating the different Browser details with dimension details
				 */
				{new BrowserDetails("chrome","browser", new Dimension(1600, 1200), asList("browser"))}
				//{new BrowserDetails("ie","browser", new Dimension(1200, 1024), asList("browser"))},
				//{new BrowserDetails("firefox","browser", new Dimension(1600, 1200), asList("browser"))}
		};
	}
	
	public void load(String uri) {
		getDriver().get(uri);
	}

	@Override
	public WebDriver createDriver(Object[] args) {
		WebDriver driver = null;

		if (args.length > 0) {
			if (args[0] != null && args[0] instanceof BrowserDetails) {
				BrowserDetails browser = (BrowserDetails)args[0];
				if(browser.getBrowserType().equals("ie")){
					System. setProperty("webdriver.ie.driver", props.getProperty("ieDriverPath")+"\\IEDriverServer.exe");
					driver = new ChromeDriver();	
				}else if(browser.getBrowserType().equals("firefox")){
					System. setProperty("webdriver.gecko.driver", System.getProperty("user.dir")+"\\geckodriver.exe");
					driver = new FirefoxDriver();
				}else{
					System. setProperty("webdriver.chrome.driver", System.getProperty("user.dir")+"\\chromedriver.exe");
					driver = new ChromeDriver();
				}

				driver.manage().window().maximize();
				if (browser.getScreenSize() != null) {
					driver.manage().window().setSize(browser.getScreenSize());
				}
			}
		}
		return driver;
	}

}
