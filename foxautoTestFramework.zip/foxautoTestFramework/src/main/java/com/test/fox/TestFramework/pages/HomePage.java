package com.test.fox.TestFramework.pages;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class HomePage extends BasePage {

	@FindBy(xpath = "//*[@id='path-1']")
	WebElement accountElement;

	@FindBy(xpath = "//*[@href='/shows/']")
	WebElement showsLink;

	@FindBy(linkText = "FX")
	WebElement fxLink;

	@FindBy(linkText = "National Geographic")
	WebElement ngLink;

	@FindBy(linkText = "All Shows")
	WebElement allShowsLink;
	
	@FindBy(linkText = "FOX Sports")
	WebElement foxsportsLink;
	

	public HomePage(WebDriver driver){
		this.driver = driver;		
		PageFactory.initElements(driver, this);
	}

	public void launchAccountScreen(){
		accountElement.click();
	}
	
	public void openShows() throws InterruptedException{
		showsLink.click();
		Thread.sleep(MIN_TIMEOUT);
	}

	public void openFXshows() throws InterruptedException{
		fxLink.click();
		Thread.sleep(MIN_TIMEOUT);
	}

	public void openNGshows() throws InterruptedException{
		ngLink.click();
		Thread.sleep(MIN_TIMEOUT);
	}

	public void openAllShows() throws InterruptedException{
		allShowsLink.click();
		Thread.sleep(MIN_TIMEOUT);
	}
	
	public void openFoxSportsShows() throws InterruptedException{
		Thread.sleep(MIN_TIMEOUT);
		foxsportsLink.click();
		Thread.sleep(MIN_TIMEOUT);
	}


}
