package com.test.fox.TestFramework.pages;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class ShowsPage extends BasePage {

	public ShowsPage(WebDriver driver){
		this.driver = driver;		
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath = "//*[@class='TileGrid_grid_vrnLT']/div")
	List<WebElement> showsList;



	public void waitForPagetoLoadAllshows(String showName) throws InterruptedException{
		boolean flag = false;
		JavascriptExecutor jse = (JavascriptExecutor)driver;
		Thread.sleep(5000);
		while(!flag){
			
			if(showsList.get(showsList.size()-1).getText().split("\\(")[0].equalsIgnoreCase(showName)){
				flag=true;
				jse.executeScript("window.scrollBy(0,-250)", "");
			}else{
				jse.executeScript("window.scrollBy(0,250)", "");
				Thread.sleep(500);
			}

		}
	}

	public ArrayList<String> getLast4Shows(){
		ArrayList<String> showsArrayList = new ArrayList<String>();
		if(showsList.size() > 0){
			int j = 1;	
			while(j<5){
				if((showsList.size()-j) >= 0){
					showsArrayList.add(showsList.get(showsList.size()-j).getText().split("\\(")[0]);
				}else{
					break;
				}
				j++;
			}
		}
		System.out.println("getLast4Shows"+showsArrayList);
		return showsArrayList;
	}

	public ArrayList<String> getAllShows(){
		ArrayList<String> showsArrayList = new ArrayList<String>();
		for(int i = 0; i<showsList.size(); i++){
			showsArrayList.add(showsList.get(i).getText().split("\\(")[0]);
		}
		System.out.println("getAllShows:"+showsArrayList);
		return showsArrayList;
	}
}
