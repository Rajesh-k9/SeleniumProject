package com.test.fox.TestFramework.utilities;

import java.awt.Color;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;
import java.util.Properties;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.*;

public class Utitlities {
	private static final String FILE_NAME = System.getProperty("user.dir")+"\\FoxShowDetails.xlsx";

	public static void createWorkBookwithHeader(){

		File file = new File(FILE_NAME);
		if(file.exists())
			file.delete();
		System.out.println("Creating excel");
		XSSFWorkbook workbook = new XSSFWorkbook();
		XSSFSheet sheet = workbook.createSheet("Shows");

		Row header = sheet.createRow(0);
		header.createCell(0).setCellValue("FOX");
		header.createCell(1).setCellValue("FX");
		header.createCell(2).setCellValue("National Geographic");
		header.createCell(3).setCellValue("FOX Sports");
		header.createCell(4).setCellValue("All Shows");
		sheet.autoSizeColumn(50000);

		try {
			FileOutputStream outputStream = new FileOutputStream(FILE_NAME);
			workbook.write(outputStream);
			workbook.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}

		System.out.println("Done");
	}

	public static void updateWorkBook(String eColumnName,ArrayList<String> foxList, ArrayList<String> otherList) throws IOException{
		FileInputStream excelFile = new FileInputStream(new File(FILE_NAME));
		XSSFWorkbook workbook = new XSSFWorkbook(excelFile);
		XSSFSheet sheet = workbook.getSheet("Shows");
		XSSFCellStyle style = workbook.createCellStyle();
		XSSFFont font = workbook.createFont();
		font.setColor(new XSSFColor(Color.RED));
		style.setFont(font);
		
		for(int j=0;j<5;j++)
		{
			Row firstRow = sheet.getRow(0);
			String columnName = firstRow.getCell(j).getStringCellValue();
			if(columnName.equals(eColumnName)){

				if(eColumnName.equalsIgnoreCase("FOX")){
					for(int i = 0; i<foxList.size();i++){

						int lastRowNumber = sheet.getLastRowNum();
						Row row = sheet.createRow(++lastRowNumber);

						Cell cell = row.createCell(j);
						cell.setCellValue(foxList.get(i));
					}
				}else{
					for(int i = 0; i<foxList.size();i++){
						int totalCount = sheet.getLastRowNum();

						for(int k=0;k<totalCount; k++){
							Row checkRow = sheet.getRow(k+1);
							for(int l=0;l<otherList.size();l++){
								if(foxList.get(k).equalsIgnoreCase(otherList.get(l))){
									Cell cell = checkRow.createCell(j);
									cell.setCellStyle(style);
									cell.setCellValue("Duplicate");
									break;
								}
							}

						}
					}
				}
				break;
			}
		}
		try {
			FileOutputStream outputStream = new FileOutputStream(FILE_NAME);
			workbook.write(outputStream);
			workbook.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public static Properties readConfigfile(String configfileName) {

		Properties properties = new Properties();
		try {
			properties.load(new FileInputStream(configfileName));
		}
		catch (IOException e) {
			e.printStackTrace();
		}
		return properties;
	}

}
