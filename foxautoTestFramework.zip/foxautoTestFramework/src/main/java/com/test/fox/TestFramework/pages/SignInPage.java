package com.test.fox.TestFramework.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class SignInPage extends BasePage {
	@FindBy(xpath = "//*[contains(@class,'Account_signIn')]")
	WebElement signInButton;
	
	@FindBy(xpath = "//*[@name='signinEmail']")
	WebElement signinEmailField;
	
	@FindBy(xpath = "//*[@name='signinPassword']")
	WebElement signinPasswordField;
	
	@FindBy(xpath = "//*[contains(@class,'Account_signinButton')]/button")
	WebElement loginButton;
	
	
	public SignInPage(WebDriver driver){
		this.driver = driver;		
		PageFactory.initElements(driver, this);
	}
	
	public void waitForSignInButton() throws InterruptedException{
		for(int i = 0; i<5;i++ )
		try{
			signInButton.isDisplayed();
		}catch(Exception e){
			Thread.sleep(SLEEP_INTERVAL);;
		}
	}
	
	public void launchSignInScreen(){
		signInButton.click();
	}
	
	public void perfomLogin(String userName, String password) throws InterruptedException{
		signinEmailField.click();
		signinEmailField.clear();
		signinEmailField.sendKeys(userName);
		
		signinPasswordField.click();
		signinPasswordField.clear();
		signinPasswordField.sendKeys(password);
		
		loginButton.click();
		Thread.sleep(MIN_TIMEOUT);
	}
}
