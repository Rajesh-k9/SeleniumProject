package com.test.fox.TestFramework.pages;

import org.openqa.selenium.WebDriver;

public class BasePage {
	protected WebDriver driver;
	protected static int MAX_TIMEOUT=5000;
	protected static int MIN_TIMEOUT=2000;
	protected static int SLEEP_INTERVAL=1000;
}
